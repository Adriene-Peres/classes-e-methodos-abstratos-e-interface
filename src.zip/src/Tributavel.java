
public interface Tributavel{
    double calcularIPVA();
}